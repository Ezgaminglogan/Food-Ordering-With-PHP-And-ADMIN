<?php
include("partials/menu.php");

// Database connection using PDO
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food-order";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Fetch all orders for tracking
$sqlAllOrders = "SELECT * FROM tbl_order ORDER BY order_date DESC";
$stmtAllOrders = $conn->prepare($sqlAllOrders);
$stmtAllOrders->execute();
$allOrders = $stmtAllOrders->fetchAll(PDO::FETCH_ASSOC);

?>


<head>
    <title>Delivery Tracking</title>
    <!-- Add your head content here -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap">
    <style>
        /* Add your custom styles here */
        body {
            background-color: #f9f9f9;
            font-family: 'Roboto', sans-serif;
        }

        .delivery-tracking {
            padding: 20px;
            background-color: white;
            margin-top: 20px;
        }

        .order-card {
            border: 1px solid #ddd;
            width: 350px;
            padding: 15px;
            margin-bottom: 20px;
            background-color: #fff;
            border-radius: 8px;
        }

        .order-card h3 {
            color: #333;
        }

        .order-details p {
            margin: 8px 0;
        }

        .view-details-btn {
            background-color: #4CAF50;
            color: white;
            border: none;
            padding: 10px 15px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }

        /* Modal styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.4);
            padding-top: 60px;
        }

        .modal-content {
            background-color: #fefefe;
            margin: 5% auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
            border-radius: 8px;
        }

        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

        .close:hover,
        .close:focus {
            color: black;
            text-decoration: none;
            cursor: pointer;
        }

        .order-status.Delivering {
            color: #ff8c00; /* Change the color for Delivering */
        }

        .order-status.Delivered {
            color: #008000; /* Change the color for Delivered */
        }

        /* Disable button style */
        .disabled-btn {
            cursor: not-allowed;
            background-color: #cccccc;
            color: #666666;
        }

        @media (max-width: 768px) {
            .delivery-tracking {
                width: 90%;
            }
        }
    </style>
</head>

<body>

    <!-- Main Content Starts Here -->
    <section class="food-search">
        <div class="container">
            <?php
            // Check if orders are placed
            if ($allOrders) {
                echo "<h2 class='text-center text-dark'>Delivery Tracking</h2>";

                foreach ($allOrders as $order) {
                    // Display each order as a card
                    echo "<div class='order-card'>";
                    echo "<h3><strong>Customer Name :</strong> {$order['fullName']}</h3>";
                    echo "<p><strong>Customer Address :</strong> {$order['address']}</p>";
                    echo "<div class='order-details'>";
                    echo "<p><strong>Food Name:</strong> {$order['food']}</p>";
                    echo "<p><strong>Status:</strong> <span class='order-status {$order['status']}'>{$order['status']}</span></p>";
                    echo "<p><strong>Mode of Payment:</strong> {$order['mode_of_payment']}</p>";
                    echo "<p><strong>Price : </strong>{$order['price']}</p>";
                    echo "<p><strong>Quantity : </strong>{$order['qty']}</p>";
                    echo "<p><strong>Total : </strong>{$order['total']}</p>";
                    echo "</div>";
                    echo "<form class='cancel-order-form'>";
                    echo "<input type='hidden' name='order_id' value='{$order['id']}'>";

                    // Check if the status is 'Delivering' or 'Delivered' to disable the button
                    if ($order['status'] == 'Delivering' || $order['status'] == 'Delivered') {
                        echo "<input type='submit' value='Cancel Order' class='view-details-btn disabled-btn' disabled>";
                    } else {
                        echo "<input type='submit' value='Cancel Order' class='view-details-btn'>";
                    }

                    echo "</form>";
                    echo "</div>";
                }
            } else {
                // If no orders are placed, display a message
                echo "<p style='color:white; text-align:center;'>No orders found. <a href='foods.php'>Order now</a></p>";
            }
            ?>
        </div>
    </section>
    <!-- Main Content Ends Here -->

    <!-- Modal for order details -->
    <div id="orderDetailsModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <div id="orderDetailsContent"></div>
        </div>
    </div>

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var orderDetailsModal = document.getElementById('orderDetailsModal');
            var orderDetailsContent = document.getElementById('orderDetailsContent');
        });

        // Cancel Order logic
        var cancelOrderForms = document.querySelectorAll('.cancel-order-form');

        cancelOrderForms.forEach(function (form) {
            form.addEventListener('submit', function (event) {
                // Prevent the default form submission
                event.preventDefault();

                // Get the order ID from the form
                var orderId = form.querySelector('input[name="order_id"]').value;

                // Check if the order is already cancelled
                var statusElement = form.closest('.order-card').querySelector('.order-status');
                if (statusElement && statusElement.textContent.trim().toLowerCase() === 'cancelled') {
                    // Display a message if the order is already cancelled
                    alert('This order is already cancelled.');
                    return;
                }

                // Submit the form using AJAX
                var xhr = new XMLHttpRequest();
                xhr.open('POST', 'cancel-order.php', true);
                xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
                xhr.onload = function () {
                    // Check if the response contains a success message
                    if (xhr.responseText.includes('Order cancelled successfully')) {
                        // Display success message
                        alert('Order cancelled successfully');

                        // Update the UI to reflect the cancelled status
                        if (statusElement) {
                            statusElement.textContent = 'Cancelled';
                        }
                    } else {
                        // Display an error message
                        alert('Error cancelling order');
                    }
                };

                // Send the request
                xhr.send('order_id=' + orderId);
            });
        });
    </script>

    <?php
        // Close the PDO connection
        $conn = null;
    include("partials/footer.php");


    ?>