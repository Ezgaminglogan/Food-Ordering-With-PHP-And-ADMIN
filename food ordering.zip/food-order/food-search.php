<?php
include('partials/menu.php');

// Replace these variables with your actual database credentials
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food-order";

try {
    // Create a PDO connection
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<!-- Food Search Section Starts Here -->
<section class="food-search text-center">
    <div class="container">
        <form action="food-search.php" method="POST">
            <input type="search" name="search" placeholder="Search for Food.." required>
            <input type="submit" name="submit" value="Search" class="btn btn-primary">
        </form>
    </div>
</section>
<!-- Food Search Section Ends Here -->

<!-- Food Menu Section Starts Here -->
<section class="food-menu">
    <div class="container">
        <h2 class="text-center">Food Menu</h2>

        <?php
        // Check if the form is submitted
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            // Get the search term from the form
            $search_term = strtolower($_POST["search"]); // Convert to lowercase for case-insensitive search

            // Perform a search based on $search_term
            $search_results = array();

            // Fetching food items from the database
            $sql = "SELECT * FROM tbl_food WHERE lower(title) LIKE :search OR lower(description) LIKE :search";
            $stmt = $conn->prepare($sql);
            $stmt->bindValue(':search', "%$search_term%");
            $stmt->execute();
            $search_results = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // Display search results
            if (!empty($search_results)) {
                echo "<div class='result-container'>";
                echo "<h2>Search results for: {$search_term}</h2>";

                // Display food items
                foreach ($search_results as $result) {
                    echo "<div class='food-menu-box'>";
                    echo "<div class='food-menu-img'>";
                    echo "<img src='images/{$result['image_name']}' alt='{$result['title']}' class='img-responsive img-curve-search'>";
                    echo "</div>";
                    echo "<div class='food-menu-desc'>";
                    echo "<h4><i class='fas fa-utensils'> {$result['title']}</i></h4>";
                    echo "<p class='food-price'>&#x20B1;" . number_format($result['price'], 2) . "</p>";
                    echo "<p class='food-detail'>{$result['description']}</p>";

                    // Form for Order Now (inside the loop, unique form for each item)
                    echo "<form action='order-now.php' method='POST'>";
                    echo "<input type='hidden' name='food' value='" . htmlspecialchars($result['title'], ENT_QUOTES, 'UTF-8') . "'>";
                    echo "<input type='hidden' name='price' value='" . htmlspecialchars($result['price'], ENT_QUOTES, 'UTF-8') . "'>";
                    echo "<button type='submit' class='btn btn-primary'>Order Now</button>";
                    echo "</form>";

                    echo "</div>";
                    echo "</div>";
                }

                echo "</div>"; // Close result-container
            } else {
                echo "<p>No results found for: {$search_term}</p>";
            }
        } else {
            echo "<p>No food item selected for order.</p>";
        }
        ?>
    </div>
    <!-- Clearing element to separate food menu and footer -->
    <div class="clearfix"></div>
</section>
<!-- Food Menu Section Ends Here -->

<!-- Footer Starts Here -->
<?php include('partials/footer.php'); ?>
<!-- Footer Ends Here -->
