<?php
include('partials/menu.php');

// Database connection using PDO
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food-order";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>


<!-- Food Search Section Starts Here -->
<section class="food-search text-center">
    <div class="container">
        <form action="food-search.php" method="POST">
            <i class="fas fa-search"></i>
            <input type="search" name="search" placeholder="Search for Food.." required>
            <button type="submit" name="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
        </form>
    </div>
</section>
<!-- Food Search Section Ends Here -->

<!-- Greetings Section Starts Here -->
<section class="greetings text-center">
    <div class="container">
        <h2 class="greetings-text">Welcome to Mom's Food Delicacy</h2>
    </div>
</section>
<!-- Greetings Section Ends Here -->

<!-- Food Menu Section Starts Here -->
<section class="food-menu">
    <div class="container">
        <h2 class="text-center">Discover Our Delicacies</h2>

        <?php
        // Fetch food items from the database
        $sql = "SELECT * FROM tbl_food WHERE active = 'Yes'";
        $result = $conn->query($sql);

        if ($result && $result->rowCount() > 0) {
            while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                echo "<div class='food-menu-box'>";
                echo "<div class='food-menu-img'>";
                echo "<img src='images/food/{$row['image_name']}' alt='{$row['title']}' class='img-responsive img-curve food-image'>";
                echo "</div>";
                echo "<div class='food-menu-desc'>";
                echo "<h4>{$row['title']}</h4>";
                echo "<p class='food-price'>&#x20B1;{$row['price']}</p>";
                echo "<p class='food-detail'>{$row['description']}</p>";
                echo "</div>";
                echo "</div>";
            }
        } else {
            echo "<p>No food items found.</p>";
        }
        ?>

        <div class="clearfix"></div>
    </div>
</section>
<!-- Food Menu Section Ends Here -->

<!-- JavaScript for Responsive Navigation -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle the responsive navigation menu
    var menuToggle = document.getElementById('menu-toggle');
    var mobileMenu = document.getElementById('mobile-menu');
});
</script>

<!-- Include the footer from footer.php -->
<?php include('partials/footer.php'); ?>