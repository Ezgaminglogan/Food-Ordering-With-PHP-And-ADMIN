<?php

session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <!-- Important to make website responsive -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mom's Food Delicacies</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="css/style.css">


    <!-- Link FontAwesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- ICONS -->
    <link rel="shortcut icon" href="icon/drool.png" type="image/x-icon">
</head>

<body>
    <!-- Navbar Section Starts Here -->
    <section class="navbar">
        <div class="container">
            <div class="logo">
                <a href="indexphp" title="Logo">
                    <img src="images/logo.png" alt="Restaurant Logo" class="img-responsive">
                </a>
            </div>

            <div class="menu text-right">
                <ul>
                    <li>
                        <a href="index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li>
                        <a href="foods.php"><i class="fas fa-hamburger"></i> Foods</a>
                    </li>
                    <li>
                        <a href="order.php"><i class="fas fa-shopping-cart"></i> Order</a>
                    </li>
                </ul>
            </div>

            <div class="clearfix"></div>
        </div>
    </section>
    <!-- Navbar Section Ends Here -->
