    <!-- Social Section Starts Here -->
    <section class="social">
        <div class="container text-center">
            <ul>
                <li>
                <a href="https://www.facebook.com/cflogan.panucat2nd"><img src="https://img.icons8.com/fluent/50/000000/facebook-new.png"/></a>
                </li>
            </ul>
        </div>
    </section>
    <!-- social Section Ends Here -->

    <!-- footer Section Starts Here -->
    <section class="footer">
        <div class="container text-center">
        <p>All rights reserved. Designed By <a href="https://www.facebook.com/cflogan.panucat2nd">Logan M. Panucat</a></p>
        </div>
    </section>
    <!-- footer Section Ends Here -->

</body>
</html>