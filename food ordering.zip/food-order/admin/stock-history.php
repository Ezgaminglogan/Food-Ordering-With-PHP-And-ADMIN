<?php
include('partial/menu.php');

// Database connection using PDO
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food-order";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

?>

<!-- Add your head content here -->
<style>
    /* Add your custom styles here */
    .stock-history {
        padding: 20px;
    }

    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    table, th, td {
        border: 1px solid #ddd;
    }

    th, td {
        padding: 15px;
        text-align: left;
    }
</style>

<!-- Stock History Section Starts Here -->
<section class="stock-history">
    <div class="container">
        <h2 class="text-center text-white" style="text-align: center;">Stock History</h2>

        <?php
        // Fetch stock history from tbl_food
        $sqlStockHistory = "SELECT title, stocks, modified_at FROM tbl_food";
        $stmtStockHistory = $conn->prepare($sqlStockHistory);
        $stmtStockHistory->execute();
        $stockHistory = $stmtStockHistory->fetchAll(PDO::FETCH_ASSOC);

        if ($stockHistory) {
            echo "<table>";
            echo "<thead>";
            echo "<tr>";
            echo "<th>Food Item</th>";
            echo "<th>Stocks</th>";
            echo "<th>Last Modified Date</th>";
            echo "</tr>";
            echo "</thead>";
            echo "<tbody>";

            foreach ($stockHistory as $history) {
                $modifiedDate = new DateTime($history['modified_at']);
                echo "<tr>";
                echo "<td>{$history['title']}</td>";
                echo "<td>{$history['stocks']}</td>";
                echo "<td>{$modifiedDate->format('Y-m-d H:i:s')}</td>";
                echo "</tr>";
            }

            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<p style='color:white;'>No stock history available.</p>";
        }

        // Close the PDO connection
        $conn = null;
        ?>
    </div>
</section>
<!-- Stock History Section Ends Here -->

<!-- Footer Starts Here -->
<?php include('partial/footer.php'); ?>
<!-- Footer Ends Here -->
