<?php
include('partial/menu.php');

// Check if the food ID is set
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $food_id = $_GET['id'];

    // Get the image name of the food
    $sql_select_image = "SELECT image_name FROM tbl_food WHERE id = :food_id";
    $stmt_select_image = $conn->prepare($sql_select_image);
    $stmt_select_image->bindParam(':food_id', $food_id);
    $stmt_select_image->execute();
    $result_image = $stmt_select_image->fetch(PDO::FETCH_ASSOC);

    // Check if the food exists in the database
    if ($result_image) {
        $image_name = $result_image['image_name'];

        // Delete the food from the database
        $sql_delete_food = "DELETE FROM tbl_food WHERE id = :food_id";
        $stmt_delete_food = $conn->prepare($sql_delete_food);
        $stmt_delete_food->bindParam(':food_id', $food_id);

        if ($stmt_delete_food->execute()) {
            // Food deleted successfully
            $_SESSION['delete-food'] = "<div class='success' style='text-align:center;'>Food Deleted Successfully.</div>";

            // Remove the physical image file from the server
            $image_path = "../images/food/" . $image_name;
            if (file_exists($image_path)) {
                if (unlink($image_path)) {
                    $_SESSION['delete-food'] .= "<div class='success' style='text-align:center;'>Image File Deleted Successfully.</div>";
                } else {
                    $_SESSION['delete-food'] .= "<div class='error' style='text-align:center;'>Failed to Delete Image File.</div>";
                }
            } else {
                $_SESSION['delete-food'] .= "<div class='info' style='text-align:center;'>Image File Already Deleted.</div>";
            }
        } else {
            // Failed to delete food
            $_SESSION['delete-food'] = "<div class='error' style='text-align:center;'>Failed to Delete Food.</div>";
        }
    } else {
        // Food not found
        $_SESSION['delete-food'] = "<div class='error' style='text-align:center;'>Food not found.</div>";
    }
} else {
    // Redirect to manage-food.php if the food ID is not set
    header("Location:" . SITEURL . "admin/manage-food.php");
    exit();
}

// Redirect to manage-food.php after deleting the food
header("Location:" . SITEURL . "admin/manage-food.php");
exit();
?>
