<!-- Main -->
<?php include('partial/menu.php'); ?>

<!-- Function to get orders from the database -->
<?php
function getOrdersFromDatabase($conn) {
    // SQL query to retrieve orders
    $sql = "SELECT * FROM tbl_order"; 

    // Prepare and execute the statement
    $stmt = $conn->prepare($sql);
    $stmt->execute();

    // Fetch data
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    return $orders;
}
?>

<!-- Main -->
<div class="main-content">
    <div class="wrapper">
        <h1>Manage Order</h1>
        <br><br>
        <?php
            if(isset($_SESSION['Success'])){
                echo $_SESSION['Success'];
                unset($_SESSION['Success']);
            }else if(isset($_SESSION['Success-delete'])){
                echo $_SESSION['Success-delete'];
                unset($_SESSION['Success-delete']);
            }
        ?>
        <br><br>    
        <!-- Display order information -->
        <table class='tbl-full'>
            <tr>
                <th>Order ID</th>
                <th>Food Item</th>
                <th>Price</th>
                <th>Quantity</th>
                <th>Total Price</th>
                <th>Phone Number</th>
                <th>Customers Name</th>
                <th>Customers Address</th>
                <th>Mode of Payment</th>
                <th>Order Date</th>
                <th>Status</th>
                <th style="width: 300px;">Actions</th>
            </tr>
            <?php
            // Fetch and display orders from your database
            // Modify this part based on how you store order information in your database
            $orders = getOrdersFromDatabase($conn); // Pass the connection to the function

            foreach ($orders as $order) {
                echo "<tr>";
                echo "<td>{$order['id']}</td>";
                    
                // Modify this line to use the correct key from your database
                echo "<td>{$order['food']}</td>";   
                
                echo "<td>{$order['price']}</td>";
                echo "<td>{$order['qty']}</td>";
                echo "<td>{$order['total']}</td>";

                echo "<td>{$order['phone_number']}</td>";
                echo "<td>{$order['fullName']}</td>";
                echo "<td>{$order['address']}</td>";
                echo "<td>{$order['mode_of_payment']}</td>";
                echo "<td>{$order['order_date']}</td>";
                echo "<td>{$order['status']}</td>";
                echo "<td>
                        <a href='update-order.php?order_id={$order['id']}' class='btn-secondary'>Update Status</a>
                        <a href='delete-order.php?order_id={$order['id']}' class='btn-danger'>Delete Order</a>
                      </td>";
                echo "</tr>";
            }
            ?>
        </table>
    </div>
</div>

<!-- Footer -->
<?php include('partial/footer.php'); ?>
