<?php 
include('partial/menu.php');
?>

<!-- Main Content Section Starts -->
<div class="main-content">
    <div class="wrapper">

        <?php
        // Check if the login was successful
        if (isset($_SESSION['login_success']) && $_SESSION['login_success'] === true) {
            echo '<p style="color: green; text-align:center;">Login successful!</p>';
            // Reset the session variable to avoid displaying the message on subsequent visits
            $_SESSION['login_success'] = false;
        }
        ?>

        <h1>Dashboard</h1>

        <!-- Retrieve and display the count of food items -->
        <?php
        $sqlFoodCount = "SELECT COUNT(*) AS food_count FROM tbl_food";
        $resultFoodCount = $conn->query($sqlFoodCount);
        
        if ($resultFoodCount && $resultFoodCount->rowCount() > 0) {
            $foodCount = $resultFoodCount->fetch(PDO::FETCH_ASSOC)['food_count'];
            echo "<div class='col-4' style='text-align: center;'><h1>$foodCount</h1><br>Food Items</div>";
        } else {
            echo "<div class='col-4' style='text-align: center;'><h1>0</h1><br>Food Items</div>";
        }
        ?>

        <!-- Retrieve and display the count of users -->
        <?php
        $sqlUserCount = "SELECT COUNT(*) AS user_count FROM tbl_admin";
        $resultUserCount = $conn->query($sqlUserCount);

        if ($resultUserCount && $resultUserCount->rowCount() > 0) {
            $userCount = $resultUserCount->fetch(PDO::FETCH_ASSOC)['user_count'];
            echo "<div class='col-4' style='text-align: center;'><h1>$userCount</h1><br>Users</div>";
        } else {
            echo "<div class='col-4' style='text-align: center;'><h1>0</h1><br>Users</div>";
        }
        ?>

        <!-- Retrieve and display the count of orders -->
        <?php
        $sqlOrderCount = "SELECT COUNT(*) AS order_count FROM tbl_order";
        $resultOrderCount = $conn->query($sqlOrderCount);

        if ($resultOrderCount && $resultOrderCount->rowCount() > 0) {
            $orderCount = $resultOrderCount->fetch(PDO::FETCH_ASSOC)['order_count'];
            echo "<div class='col-4' style='text-align: center;'><h1>$orderCount</h1><br>Orders</div>";
        } else {
            echo "<div class='col-4' style='text-align: center;'><h1>0</h1><br>Orders</div>";
        }
        ?>

        <!-- Display summary of total money for orders with statuses "delivering" and "delivered" -->
        <?php
            $sqlTotalMoney = "SELECT SUM(total) AS total_money FROM tbl_order WHERE status IN ('delivering', 'delivered')";
            $resultTotalMoney = $conn->query($sqlTotalMoney);

            if ($resultTotalMoney && $resultTotalMoney->rowCount() > 0) {
                $totalMoney = $resultTotalMoney->fetch(PDO::FETCH_ASSOC)['total_money'];
                echo "<div class='col-4' style='text-align: center;'><h1>₱ $totalMoney</h1><br>Total Money</div>";
            } else {
                echo "<div class='col-4' style='text-align: center;'><h1>₱ N/A </h1><br>Total Money</div>";
            }
        ?>

        <!-- Add more sections for other statistics as needed -->

        <div class="clearFix"></div>

    </div>
</div>
<!-- Main Section Section Ends -->

<?php include('partial/footer.php'); ?>