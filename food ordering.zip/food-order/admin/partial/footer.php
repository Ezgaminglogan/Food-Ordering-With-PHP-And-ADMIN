 <!-- Footer Section Starts -->
 <div class="footer">
        <div class="wrapper">
           <pre style="text-align: center;">&copy; 2023 All Right Reserved, Developed by <a href="https://www.facebook.com/Cflogan.Panucat2nd">Logan M. Panucat </a></pre>
        </div>
    </div>
    <!-- Footer Section Ends -->
</body>
</html>