<?php
    // Include the file containing constants first
    require_once __DIR__ . '/../connection/db_connect.php';


    // Check if the user is not logged in
    if (!isset($_SESSION['user'])) {
        // If the user is not logged in, redirect to the login page
        $_SESSION['no-login-message'] = "<div class='error' style='text-align:center; color:red;'>Please log in to access the admin panel.</div>";
        header("Location:".SITEURL.'admin/login-admin.php');
        exit();
    }
?>
