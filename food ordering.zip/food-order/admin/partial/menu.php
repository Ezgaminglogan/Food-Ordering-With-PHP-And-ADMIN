<?php
    require_once __DIR__ . '/../connection/db_connect.php';
    include('login-checker.php');

    function getCategoryName($conn, $category_id)
{
    $sql = "SELECT title FROM tbl_category WHERE id = :category_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':category_id', $category_id, PDO::PARAM_INT);
    $stmt->execute();

    if ($stmt->rowCount() > 0) {
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row['title'];
    } else {
        return "Category Not Found";
    }
}


?>




<!-- HTML -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mom's Delicacies Website - ADMIN PANEL</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="shortcut icon" href="../icon/drool.png" type="image/x-icon">
</head>
<body>
    <!-- Menu Section Starts -->
    <div class="menu" >
        <div class="wrapper">
            <ul>
                <li><a href='index.php'>Home</a></li>
                <li><a href='manage-admin.php'>Admin</a></li>
                <li><a href='manage-food.php'>Food</a></li>
                <li><a href='manage-order.php'>Order</a></li>
                <li><a href='stock-history.php'>Stock History</a></li> 
                <li><a href='logout-admin.php'>Logout</a></li>                
            </ul>
        </div>
    </div>
    <!-- Menu Section End -->