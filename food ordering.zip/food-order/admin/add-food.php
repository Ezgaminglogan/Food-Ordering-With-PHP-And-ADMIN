<?php
// Include the necessary files and start the session
include('partial/menu.php');

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stocks = $_POST['stocks'];
    $active = isset($_POST['active']) ? $_POST['active'] : 'No';

    // Validation
    $errors = array();

    // Check if title is empty
    if (empty($title)) {
        $errors[] = "Title is required.";
    }

    // Check if description is empty
    if (empty($description)) {
        $errors[] = "Description is required.";
    }

    // Check if price is empty or not a valid number
    if (empty($price) || !is_numeric($price)) {
        $errors[] = "Price is required and must be a valid number.";
    }

    // Check if stocks is empty or not a valid number
    if (empty($stocks) || !is_numeric($stocks)) {
        $errors[] = "Stocks is required and must be a valid number.";
    }

    // Display errors if any
    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<div class='error'>$error</div>";
        }
        // Stop further processing
        exit();
    }

    // Image upload handling
    $target_dir = "../images/food/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if a new image is provided
    if (!empty($_FILES["image"]["name"])) {
        // Check if the file is an actual image or fake image
        $check = getimagesize($_FILES["image"]["tmp_name"]);
        if ($check === false) {
            echo "<div class='error'>File is not an image.</div>";
            $uploadOk = 0;
        }

        // Check if the file already exists
        if (file_exists($target_file)) {
            echo "<div class='error'>Sorry, file already exists.</div>";
            $uploadOk = 0;
        }

        // Check file size
        if ($_FILES["image"]["size"] > 500000) {
            echo "<div class='error'>Sorry, your file is too large.</div>";
            $uploadOk = 0;
        }

        // Allow certain file formats
        $allowedFormats = ["jpg", "jpeg", "png", "gif"];
        if (!in_array($imageFileType, $allowedFormats)) {
            echo "<div class='error'>Sorry, only JPG, JPEG, PNG, GIF files are allowed.</div>";
            $uploadOk = 0;
        }
    }

    // If there are no errors in the image upload, proceed with the database insertion
    if ($uploadOk == 1) {
        // Move the new image to the target directory
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            // SQL to insert data into tbl_food
            $sql = "INSERT INTO tbl_food (title, description, price, stocks, image_name, active) VALUES (:title, :description, :price, :stocks, :image, :active)";

            // Prepare the SQL statement
            $stmt = $conn->prepare($sql);

            // Get the image file name from the variable
            $imageFileName = basename($_FILES["image"]["name"]);

            // Bind parameters
            $stmt->bindParam(':title', $title);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':stocks', $stocks);
            $stmt->bindParam(':image', $imageFileName);
            $stmt->bindParam(':active', $active);

            // Execute the query
            if ($stmt->execute()) {
                // Food added successfully
                $_SESSION['add-food'] = "<div class='success' style='text-align:center;'>Food Added Successfully.</div>";
                header("Location:" . SITEURL . "admin/manage-food.php"); // Redirect to the food management page
                exit();
            } else {
                // Failed to add food
                $_SESSION['add-food'] = "<div class='error'>Failed to Add Food.</div>";
            }
        } else {
            echo "<div class='error'>Sorry, there was an error uploading your file.</div>";
        }
    } else {
        // Display an error message
        echo "<div class='error'>Error adding food: Image upload failed.</div>";
    }
}
?>

<!-- Main content starts here -->
<div class="main-content">
    <div class="wrapper">
        <h1>Add Food</h1>
        <br><br>

        <!-- Display messages, if any -->
        <?php
        if (isset($_SESSION['add-food'])) {
            echo $_SESSION['add-food'];
            unset($_SESSION['add-food']);
        }
        ?>

        <!-- Add Food Form -->
        <form method="POST" action="" enctype="multipart/form-data">
            <table class="tbl-30">
                <tr>
                    <td>Title: </td>
                    <td>
                        <input type="text" name="title" required>
                    </td>
                </tr>

                <tr>
                    <td>Description: </td>
                    <td>
                        <textarea name="description" rows="5" required></textarea>
                    </td>
                </tr>

                <tr>
                    <td>Price: </td>
                    <td>
                        <input type="number" name="price" required>
                    </td>
                </tr>

                <tr>
                    <td>Stocks: </td>
                    <td>
                        <input type="number" name="stocks" required>
                    </td>
                </tr>

                <tr>
                    <td>Type: </td>
                    <td>
                        <select name="type" required>
                            <option value="Food">Food</option>
                        </select>
                    </td>
                </tr>

                <tr>
                    <td>Active: </td>
                    <td>
                        <input type="radio" name="active" value="Yes"> Yes
                    </td>
                    <td>
                        <input type="radio" name="active" value="No" checked> No
                    </td>
                </tr>

                <tr>
                    <td>Image: </td>
                    <td>
                        <input type="file" name="image" accept="image/*" required>
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" value="Add Food" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<!-- Main content ends here -->

<!-- Footer -->
<?php include('partial/footer.php'); ?>

<?php
// Close the PDO connection
$conn = null;
?>
