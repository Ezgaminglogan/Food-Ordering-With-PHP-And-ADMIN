<!-- Main -->
<?php include('partial/menu.php'); ?>

<!-- Main -->
<div class="main-content">
    <div class="wrapper">
        <h1>Manage Food</h1>
        <br><br>

        <!-- Message for Adding or Deleting Food -->
        <?php 
            if(isset($_SESSION['add-food'])){
                echo $_SESSION['add-food'];
                unset($_SESSION['add-food']);
            }

            if(isset($_SESSION['delete-food'])){
                echo $_SESSION['delete-food'];
                unset($_SESSION['delete-food']);
            }

            if(isset($_SESSION['update-food'])){
                echo $_SESSION['update-food'];
                unset($_SESSION['update-food']);
            }
        ?>

        <br><br>

        <!-- Button For Adding Food -->
        <a href="<?php echo SITEURL; ?>admin/add-food.php" class="btn-primary">Add Food?</a>

        <br><br><br>

        <table class='tbl-full'>
            <tr>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Price</th>
                <th>Stocks</th>
                <th>Image</th>
                <th>Active</th>
                <th style="width: 230px;">Actions</th> 
            </tr>

            <?php
            // Query to fetch data from tbl_food
            $sql = "SELECT * FROM tbl_food";
            $result = $conn->query($sql);

            if ($result->rowCount() > 0) {
                $id = 1;
                while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>";
                    echo "<td>" . $id . "</td>";
                    echo "<td>" . $row['title'] . "</td>";
                    echo "<td>" . $row['description'] . "</td>";
                    echo "<td>" . $row['price'] . "</td>";
                    echo "<td>" . $row['stocks'] . "</td>";
                    echo "<td><img src='../images/food/{$row['image_name']}' alt='{$row['title']} Image' class='img-responsive' width='100'></td>";
                    echo "<td>" . $row['active'] . "</td>";
                    echo "<td>";
                    echo "<a href='update-food.php?id={$row['id']}' class='btn-secondary'>Update Food</a>";
                    echo "<a href='delete-food.php?id={$row['id']}' class='btn-danger'>Delete Food</a>";
                    echo "</td>";
                    echo "</tr>";
                    $id++;
                }
            } else {
                echo "<tr><td colspan='8'>No food items found</td></tr>";
            }
            ?>
        </table>
    </div>
</div>

<!-- Footer -->
<?php include('partial/footer.php'); ?>
