<?php
// Include necessary files
include('partial/menu.php');

// Check if an order ID is provided in the URL
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];

    // Fetch the order details
    try {
        // Connection is assumed to be available through inclusion of partial/menu.php
        $sql = "SELECT * FROM tbl_order WHERE id = :order_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->execute();

        $order = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    // Perform the update when the form is submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // Update the delivery status in the database
        try {
            // Connection is assumed to be available through inclusion of partial/menu.php
            $new_status = $_POST['new_status'];

            $sql = "UPDATE tbl_order SET status = :status WHERE id = :order_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':status', $new_status);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();

            // Fetch the updated order details
            $sql = "SELECT * FROM tbl_order WHERE id = :order_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();

            $order = $stmt->fetch(PDO::FETCH_ASSOC);

            // Redirect back to manage-order.php after the update
            header("Location: manage-order.php");
            $_SESSION['Success'] = '<div style="text-align: center;">Successfully Update</div>';


            exit();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
} else {
    // If no order ID is provided, redirect to manage-order.php
    header("Location: manage-order.php");
    exit();
}
?>

<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    .food-search {
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        margin-top: 20px;
    }

    .food-search h2 {
        color: #333;
        font-size: 24px;
        margin-bottom: 20px;
    }

    .order fieldset {
        border: 1px solid #ccc;
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
    }

    .order legend {
        font-size: 18px;
        font-weight: bold;
        color: #333;
    }

    .order label {
        display: block;
        margin-bottom: 8px;
        font-size: 14px;
        color: #555;
    }

    .order span {
        display: inline-block;
        padding: 8px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        background-color: #f9f9f9;
        font-size: 14px;
        color: #333;
    }

    .order select {
        width: 100%;
        padding: 10px;
        margin-bottom: 15px;
        border: 1px solid #ddd;
        border-radius: 4px;
        box-sizing: border-box;
        font-size: 14px;
        color: #555;
    }

    .order input[type="submit"] {
        background-color: #4caf50;
        color: #fff;
        border: none;
        padding: 10px 20px;
        font-size: 16px;
        border-radius: 4px;
        cursor: pointer;
        transition: background-color 0.3s;
    }

    .order input[type="submit"]:hover {
        background-color: #45a049;
    }

    /* Container */
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 0 20px;
    }

    /* Footer */
    .footer {
        background-color: #333;
        padding: 20px 0;
        color: #fff;
        text-align: center;
        position: fixed;
        bottom: 0;
        width: 100%;
	height: 3vh;
    }
</style>

<!-- Update Order Section Starts Here -->
<section class="food-search" style="background-color: aliceblue;">
    <div class="container">
        <h2 class="text-center text-white">Update Order Status</h2>

        <!-- Display the order details and update form -->
        <form action="" method="POST" class="order">
            <fieldset>
                <legend>Order Details</legend>

                <div>
                    <label for="food">Food Item:</label>
                    <span><?php echo $order['food']; ?></span>
                </div>

                <div>
                    <label for="quantity">Quantity:</label>
                    <span><?php echo $order['qty']; ?></span>
                </div>

                <div>
                    <label for="total">Total Price:</label>
                    <span><?php echo $order['total']; ?></span>
                </div>

                <div>
                    <label for="order_date">Order Date:</label>
                    <span><?php echo $order['order_date']; ?></span>
                </div>

                <div>
                    <label for="status">Current Status:</label>
                    <span><?php echo $order['status']; ?></span>
                </div>

                <div>
                    <label for="new_status">New Status:</label>
                    <select name="new_status" required>
                        <option value="Ordered" <?php echo ($order['status'] == 'Ordered') ? 'selected' : ''; ?>>Ordered</option>
                        <option value="Delivering" <?php echo ($order['status'] == 'Delivering') ? 'selected' : ''; ?>>Delivering</option>
                        <option value="Delivered" <?php echo ($order['status'] == 'Delivered') ? 'selected' : ''; ?>>Delivered</option>
                        <option value="Cancelled" <?php echo ($order['status'] == 'Cancelled') ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                </div>

                <input type="submit" name="submit" value="Update Status" class="btn btn-primary">
            </fieldset>
        </form>
    </div>
</section>
<!-- Update Order Section Ends Here -->

<!-- Footer Starts Here -->
<?php include('partial/footer.php'); ?>
<!-- Footer Ends Here -->
