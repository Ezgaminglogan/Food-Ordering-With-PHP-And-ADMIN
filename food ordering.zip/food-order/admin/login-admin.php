<?php 
    include("connection/db_connect.php");

    if(isset($_POST['btnSubmit'])){
        $user = $_POST['username'];
        $pass = $_POST['password'];

        $sql = "SELECT * FROM tbl_admin WHERE username = :username";
        
        // prepare statement
        $stmt = $conn->prepare($sql);
        
        // bind parameters
        $stmt->bindParam(':username', $user);
        
        // execute query
        $stmt->execute();
        
        // check if user exists
        if($stmt->rowCount() > 0){
            // fetch user details
            $userDetails = $stmt->fetch(PDO::FETCH_ASSOC);

            // verify password
            if(password_verify($pass, $userDetails['password'])){
                // password is correct
                $_SESSION['login'] = "<div class='success' style='text-align:center;'>Log In Successful</div>";
                $_SESSION["user"] = $user; // Corrected variable name

                // Direct to Home Page / Dashboard
                header("Location:" .SITEURL."admin/index.php");
                exit();
            } else {
                // incorrect password
                $_SESSION['login'] = "<div class='error' style='text-align:center; color:red; border:1px solid red; background-color: black; border-radius: 10px;'>Failed To Login Invalid Password! Try Again!</div>";
            }
        } else {
            // user not found
            $_SESSION['login'] = "<div class='error' style='text-align:center; color:red; border:1px solid red; background-color: black; border-radius: 10px;'>Failed To Login Invalid Password / Username!</div>";
        }
    }
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mom's Delicacies Website - Log In</title>
    <link rel="stylesheet" href="../css/admin.css">
    <link rel="shortcut icon" href="../icon/drool.png" type="image/x-icon">
</head>

<body>
    <div class="login">
        <h1 style='text-align: center;'>Log In</h1>
        <br>
        <!-- Error -->

        <?php 
            if(isset($_SESSION['login'])){
                echo $_SESSION['login'];
                unset ($_SESSION['login']);
            }
        ?>
        <!-- Form Login Starts Here -->

        <form action="login-admin.php" method="post">
            <p style='text-align: center;'>Username</p>
            <input type="text" name="username" id="username" placeholder="user = admin" required>
            <p style='text-align: center;'>Password</p>
            <input type="password" name="password" id="password" placeholder="pass = admin / 123" required>
            <br>
            <button type="submit" name="btnSubmit">Log In</button>
        </form>

        <!-- Form Login Ends Here -->
        <!-- Footer Starts Here -->
        <br>
        <br>
        <br>
        <br>
        <br>
        <br>        
        <p style='text-align: center;'>Created By - <a href="http://facebook.com/Cflogan.Panucat2nd">Logan M.
                Panucat</a>&triangle;</p>
        <!-- Footer Ends Here -->
    </div>
</body>

</html>
