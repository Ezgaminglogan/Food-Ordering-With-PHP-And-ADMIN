<?php
// Include the database connection file
include('connection/db_connect.php');


$message = ""; // Initialize an empty message variable

// Check if the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $adminId = $_POST['admin_id']; // Assuming you have an input field with the name 'admin_id'
    $fullName = $_POST['full_name'];
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password

    // Update data in tbl_admin
    $sql = "UPDATE tbl_admin SET full_name = :full_name, username = :username, password = :password WHERE id = :id";
    $stmt = $conn->prepare($sql);

    // Bind parameters
    $stmt->bindParam(':id', $adminId); // Use 'id' instead of 'admin_id'
    $stmt->bindParam(':full_name', $fullName);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':password', $password);

    // Execute the statement
    if ($stmt->execute()) {
        $message = "Admin updated successfully!";
        $_SESSION['message'] = $message; // Save the message in session
        header("Location:" .SITEURL. 'admin/manage-admin.php'); // Redirect to manage-admin.php
        exit();
    } else {
        $message = "Error: " . $stmt->errorInfo()[2];
    }
}
?>

<?php include('partial/menu.php');?>

<!-- Main Content Section Starts -->
<div class="main-content">
    <div class="wrapper">
        <h1 style="text-align: center;">Update Admin</h1>

        <!-- Display the message -->
        <?php if (!empty($message)) : ?>
            <p style="text-align: center; color: <?php echo $messageColor; ?>;"><?php echo $message; ?></p>
        <?php endif; ?>

        <!-- Update Admin Form -->
        <form method="POST" action="update-admin.php" class='FORMADD'>
            <table>
                <tr>
                    <td>
                        <input type="hidden" name="admin_id" value="<?php echo $_GET['id']; ?>">
                        <!-- Add a hidden field to store the admin_id -->
                        <input type="text" id="full_name" name="full_name" required>
                        <label for="full_name">Full Name</label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="text" id="username" name="username" required>
                        <label for="username">Username</label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="password" id="password" name="password" required>
                        <label for="password">Password</label>
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" value="Update Admin" class="btn-primary">
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>
<!-- Main Section Section Ends -->

<?php include('partial/footer.php');?>

<?php
// Close the PDO connection
$conn = null;
?>
