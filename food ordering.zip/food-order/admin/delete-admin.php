<?php
// Include the database connection file
include('connection/db_connect.php');


$message = ""; // Initialize an empty message variable

// Check if the admin ID is provided in the URL
if (isset($_GET['id'])) {
    $adminId = $_GET['id'];

    // Delete data from tbl_admin
    $sql = "DELETE FROM tbl_admin WHERE id = :id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':id', $adminId);

    // Execute the statement
    if ($stmt->execute()) {
        $message = "Admin deleted successfully!";
        $_SESSION['message'] = $message; // Save the message in session
        header("Location:".SITEURL."admin/manage-admin.php"); // Redirect to manage-admin.php
        exit();
    } else {
        $message = "Error: " . $stmt->errorInfo()[2];
    }
} else {
    // Redirect to manage-admin.php if admin ID is not provided
    header("Location:".SITEURL."admin/manage-admin.php");
    exit();
}
?>

<?php include('partial/menu.php');?>

<!-- Main Content Section Starts -->
<div class="main-content">
    <div class="wrapper">
        <h1 style="text-align: center;">Delete Admin</h1>

        <!-- Display the message -->
        <?php if (!empty($message)) : ?>
            <p style="text-align: center; color: <?php echo $messageColor; ?>;"><?php echo $message; ?></p>
        <?php endif; ?>
    </div>
</div>
<!-- Main Section Section Ends -->

<?php include('partial/footer.php');?>

<?php
// Close the PDO connection
$conn = null;
?>
