<?php
// Include necessary files
include('partial/menu.php');

// Check if an order ID is provided in the URL
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];

    // Fetch the order details
    try {
        $sql = "SELECT * FROM tbl_order WHERE id = :order_id";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':order_id', $order_id);
        $stmt->execute();

        $order = $stmt->fetch(PDO::FETCH_ASSOC);
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    }

    // Check if the "No" button is clicked
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['cancel_delete'])) {
        header('Location: manage-order.php');
        exit();
    }

    // Check if the user has confirmed the deletion
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_delete'])) {
        try {
            // Delete the order
            $sql = "DELETE FROM tbl_order WHERE id = :order_id";
            $stmt = $conn->prepare($sql);
            $stmt->bindParam(':order_id', $order_id);
            $stmt->execute();

            // Set a session variable indicating successful deletion
            $_SESSION['delete_success'] = true;

            // Redirect back to manage-order.php after the deletion
            header("Location: manage-order.php");
            $_SESSION['Success-delete'] = '<div style="text-align: center;">Successfully Deleted Order</div>';
            exit();
        } catch (PDOException $e) {
            echo "Error: " . $e->getMessage();
        }
    }
} else {
    // If no order ID is provided, redirect to manage-order.php
    header("Location: manage-order.php");
    exit();
}
?>
<style>
    body {
        background-color: #f2f2f2;
        font-family: Arial, sans-serif;
    }

    .container {
        max-width: 800px;
        margin: 0 auto;
        background-color: #fff;
        padding: 20px;
        border-radius: 10px;
        margin-top: 50px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h2 {
        text-align: center;
        color: #333;
    }

    form {
        text-align: left;
        margin-top: 20px;
    }

    fieldset {
        border: 1px solid #ddd;
        padding: 10px;
        border-radius: 5px;
        margin-bottom: 20px;
    }

    label {
        display: block;
        margin-bottom: 5px;
        font-weight: bold;
    }

    span {
        display: block;
        margin-bottom: 10px;
    }

    .btn {
        padding: 10px 15px;
        font-size: 16px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .btn-primary {
        background-color: #3498db;
        color: #fff;
        margin-right: 10px;
    }

    .btn-secondary {
        background-color: #95a5a6;
        color: #fff;
    }
</style>


<!-- Delete Order Confirmation Section Starts Here -->
<section class="food-search">
    <div class="container">
        <h2 class="text-center text-white">Confirm Deletion</h2>

        <!-- Display the order details and confirmation form -->
        <form action="" method="POST">
            <fieldset>
                <legend>Order Details</legend>

                <div>
                    <label for="food">Food Item:</label>
                    <span><?php echo $order['food']; ?></span>
                </div>

                <div>
                    <label for="quantity">Quantity:</label>
                    <span><?php echo $order['qty']; ?></span>
                </div>

                <div>
                    <label for="total">Total Price:</label>
                    <span><?php echo $order['total']; ?></span>
                </div>

                <div>
                    <label for="order_date">Order Date:</label>
                    <span><?php echo $order['order_date']; ?></span>
                </div>

                <div>
                    <label for="status">Current Status:</label>
                    <span><?php echo $order['status']; ?></span>
                </div>

                <div>
                    <label for="confirm_delete">Are you sure you want to delete this order?</label>
                    <input type="submit" name="confirm_delete" value="Yes" class="btn btn-primary">
                    <input type="submit" name="cancel_delete" value="No" class="btn btn-secondary">
                </div>
            </fieldset>
        </form>
    </div>
</section>
<!-- Delete Order Confirmation Section Ends Here -->

<!-- Footer Starts Here -->
<?php include('partial/footer.php'); ?>
<!-- Footer Ends Here -->
