<?php
// Include the database connection file
include('connection/db_connect.php');


?>

<?php include('partial/menu.php');?>

<!-- Main Content Section Starts -->
<div class="main-content">
    <div class="wrapper">
        <!-- Display the success message -->
        <?php if (!empty($_SESSION['message'])) : ?>
            <p style="text-align: center; color: <?php echo $messageColor; ?>;"><?php echo $_SESSION['message']; ?></p>
            <?php unset($_SESSION['message']); ?> <!-- Unset the message to clear it after display -->
        <?php endif; ?>

        <h1>Manage Admin</h1>
        <br><br>

        <!-- Button For Adding Admin -->
        <a href="add-admin.php" class="btn-primary">Add Admin?</a>
        <br><br><br>

        <table class='tbl-full'>
            <tr>
                <th>S.N</th>
                <th>Full Name</th>
                <th>Username</th>
                <th>Actions</th>
            </tr>

            <?php
            // Query to fetch data from tbl_admin
            $sql = "SELECT * FROM tbl_admin";
            $stmt = $conn->prepare($sql);
            $stmt->execute();

            // Check if any rows were returned
            if ($stmt->rowCount() > 0) {
                $sn = 1; // Serial number counter

                // Fetch data and display it in the table
                while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<tr>
                            <td>{$sn}</td>
                            <td>{$row['full_name']}</td>
                            <td>{$row['username']}</td>
                            <td>
                                <a href='update-admin.php?id={$row['id']}' class='btn-secondary'>Update Admin</a>
                                <a href='delete-admin.php?id={$row['id']}' class='btn-danger'>Delete Admin</a>
                            </td>
                          </tr>";
                
                    $sn++; // Increment serial number
                }
            } else {
                // Display a message if no admin records are found
                echo "<tr><td colspan='4'>No Admins Found</td></tr>";
            }
            ?>

        </table>
    </div>
</div>
<!-- Main Section Section Ends -->

<?php include('partial/footer.php');?>

<?php
// Close the PDO connection
$conn = null;
?>
