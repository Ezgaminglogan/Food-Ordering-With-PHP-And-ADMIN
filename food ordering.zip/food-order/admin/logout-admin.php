<?php 
    include("connection/db_connect.php");
    session_destroy();
    header("Location:".SITEURL."admin/login-admin.php");
?>