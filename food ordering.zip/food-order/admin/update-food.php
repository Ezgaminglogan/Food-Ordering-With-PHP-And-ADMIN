<?php
// Include the necessary files and start the session
include('partial/menu.php');

// Check if the ID is set in the URL
if (isset($_GET['id'])) {
    $food_id = $_GET['id'];

    // Fetch the food details from the database based on the ID
    $sql = "SELECT * FROM tbl_food WHERE id = :food_id";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':food_id', $food_id);
    $stmt->execute();
    
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$result) {
        // Food not found
        header("Location:" . SITEURL . "admin/manage-food.php");
        exit();
    }
} else {
    // ID not set, redirect to manage-food.php
    header("Location:" . SITEURL . "admin/manage-food.php");
    exit();
}

// Process form submission for updating food
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get form data
    $title = $_POST['title'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stocks = $_POST['stocks'];
    $featured = isset($_POST['featured']) ? $_POST['featured'] : 'No';
    $active = isset($_POST['active']) ? $_POST['active'] : 'No';

    // Check if any field has changed
    if (
        $title !== $result['title'] ||
        $description !== $result['description'] ||
        $price !== $result['price'] ||
        $stocks !== $result['stocks'] ||
        $active !== $result['active'] ||
        !empty($_FILES["image"]["name"])
    ) {
        // Check if a new image is provided
        if (!empty($_FILES["image"]["name"])) {
            // Image upload handling
            $target_dir = "../images/food/";
            $target_file = $target_dir . basename($_FILES["image"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

            // Check if the file is an actual image or fake image
            $check = getimagesize($_FILES["image"]["tmp_name"]);
            if ($check === false) {
                echo "<div class='error'>File is not an image.</div>";
                $uploadOk = 0;
            }

            // Check if the file already exists
            if (file_exists($target_file)) {
                echo "<div class='error'>Sorry, file already exists.</div>";
                $uploadOk = 0;
            }

            // Check file size
            if ($_FILES["image"]["size"] > 500000) {
                echo "<div class='error'>Sorry, your file is too large.</div>";
                $uploadOk = 0;
            }

            // Allow certain file formats
            $allowedFormats = ["jpg", "jpeg", "png", "gif"];
            if (!in_array($imageFileType, $allowedFormats)) {
                echo "<div class='error'>Sorry, only JPG, JPEG, PNG, GIF files are allowed.</div>";
                $uploadOk = 0;
            }

            // If there are no errors in the image upload, proceed with the database and file update
            if ($uploadOk == 1) {
                // Move the new image to the target directory
                if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                    // Update both database and physical image
                    // SQL to update data in tbl_food
                    $sql = "UPDATE tbl_food SET 
                            title = :title, 
                            description = :description, 
                            price = :price, 
                            stocks = :stocks,
                            image_name = :image, 
                            active = :active 
                            WHERE id = :food_id";

                    // Prepare the SQL statement
                    $stmt = $conn->prepare($sql);

                    // Bind parameters
                    $stmt->bindParam(':food_id', $food_id);
                    $stmt->bindParam(':title', $title);
                    $stmt->bindParam(':description', $description);
                    $stmt->bindParam(':price', $price);
                    $stmt->bindParam(':stocks', $stocks);
                    $stmt->bindParam(':image', basename($_FILES["image"]["name"]));
                    $stmt->bindParam(':active', $active);

                    // Execute the query
                    if ($stmt->execute()) {
                        // Food updated successfully
                        $_SESSION['update-food'] = "<div class='success'>Food Updated Successfully.</div>";
                        header("Location:" . SITEURL . "admin/manage-food.php"); // Redirect to the food management page
                        exit();
                    } else {
                        // Failed to update food
                        $_SESSION['update-food'] = "<div class='error'>Failed to Update Food.</div>";
                    }
                } else {
                    echo "<div class='error'>Sorry, there was an error uploading your file.</div>";
                }
            } else {
                // Display an error message
                echo "<div class='error'>Error updating food: Image upload failed.</div>";
            }
        } else {
            // No new image, update only text and categories in the database
        // SQL to update data in tbl_food
        $sql = "UPDATE tbl_food SET 
                title = :title, 
                description = :description, 
                price = :price, 
                stocks = :stocks,
                active = :active,
                modified_at = current_timestamp() -- Add this line
                WHERE id = :food_id";

        // Prepare the SQL statement
        $stmt = $conn->prepare($sql);

        // Bind parameters
        $stmt->bindParam(':food_id', $food_id);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':price', $price);
        $stmt->bindParam(':stocks', $stocks);
        $stmt->bindParam(':active', $active);

        // Execute the query
        if ($stmt->execute()) {
            // Food updated successfully
            $_SESSION['update-food'] = "<div class='success'>Food Updated Successfully.</div>";
            header("Location:" . SITEURL . "admin/manage-food.php"); // Redirect to the food management page
            exit();
        } else {
            // Failed to update food
            $_SESSION['update-food'] = "<div class='error'>Failed to Update Food.</div>";
        }
                }
        } else {
                // No changes
                $_SESSION['update-food'] = "<div class='error'>No changes made.</div>";
        }
}
?>

<!-- Main content starts here -->
<div class="main-content">
    <div class="wrapper">
        <h1>Update Food</h1>
        <br><br>

        <!-- Display messages, if any -->
        <?php
        if (isset($_SESSION['update-food'])) {
            echo $_SESSION['update-food'];
            unset($_SESSION['update-food']);
        }
        ?>

        <!-- Update Food Form -->
        <form method="POST" action="" enctype="multipart/form-data">
            <table class="tbl-30">
                <tr>
                    <td>Title: </td>
                    <td>
                        <input type="text" name="title" value="<?php echo $result['title']; ?>" required>
                    </td>
                </tr>

                <tr>
                    <td>Description: </td>
                    <td>
                        <textarea name="description" rows="5" required><?php echo $result['description']; ?></textarea>
                    </td>
                </tr>

                <tr>
                    <td>Price: </td>
                    <td>
                        <input type="number" name="price" value="<?php echo $result['price']; ?>" required>
                    </td>
                </tr>

                <tr>
                    <td>Stocks: </td>
                    <td>
                        <input type="number" name="stocks" value="<?php echo $result['stocks']; ?>" required>
                    </td>
                </tr>


                <tr>
                    <td>Active: </td>
                    <td>
                        <input type="radio" name="active" value="Yes"
                            <?php echo ($result['active'] == 'Yes') ? 'checked' : ''; ?>> Yes
                    </td>
                    <td>
                        <input type="radio" name="active" value="No"
                            <?php echo ($result['active'] == 'No') ? 'checked' : ''; ?>> No
                    </td>
                </tr>

                <tr>
                    <td>Image: </td>
                    <td>
                        <input type="file" name="image" accept="image/*">
                    </td>
                </tr>

                <tr>
                    <td colspan="2">
                        <input type="submit" value="Update Food" class="btn-secondary">
                    </td>
                </tr>
            </table>
        </form>
        <br>
        <a href="<?php echo SITEURL; ?>admin/manage-food.php" class="btn-secondary">Cancel</a>
    </div>
</div>
<!-- Main content ends here -->

<!-- Footer -->
<?php include('partial/footer.php'); ?>

<?php
// Close the PDO connection
$conn = null;
?>