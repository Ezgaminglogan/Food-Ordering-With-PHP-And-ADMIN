<!-- Menu Starts Here -->
<?php include('partials/menu.php');

// Database connection using PDO
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food-order";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

?>
<!-- Internal Css Style Stars Here -->
<style>
        .food-menu-box {
            margin-bottom: 20px;
        }

        .food-menu-img img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }

        .food-menu-desc {
            text-align: center;
        }
    </style>

<!-- Internal Css Style Ends Here -->
<!-- Menu Ends Here -->
<!-- fOOD sEARCH Section Starts Here -->
<section class="food-search text-center">
    <div class="container">
        <form action="food-search.php" method="POST">
            <i class="fas fa-search"></i>
            <input type="search" name="search" placeholder="Search for Food.." required>
            <button type="submit" name="submit" class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
        </form>
    </div>
</section>
<!-- fOOD sEARCH Section Ends Here -->

    <!-- fOOD MEnu Section Starts Here -->
    <section class="food-menu">
        <div class="container">
            <h2 class="text-center">Food Menu</h2>

            <?php
            // Fetching food items from the database
            $sql = "SELECT * FROM tbl_food WHERE active = 'Yes'";
            $stmt = $conn->prepare($sql);
            $stmt->execute();
            $foods = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Check if there are any food items
            if ($foods) {
                foreach ($foods as $food) {
                    ?>
                    <div class="food-menu-box">
                        <div class="food-menu-img">
                            <img src="images/<?php echo $food['image_name']; ?>" alt="<?php echo $food['title']; ?>" class="img-responsive img-curve">
                        </div>

                        <div class="food-menu-desc">
                            <h4><i class="fas fa-utensils"></i> <?php echo $food['title']; ?></h4>
                            <p class="food-price">&#x20B1; <?php echo $food['price']; ?></p>
                            <p class="food-detail">
                                <?php echo $food['description']; ?>
                            </p>
                            <br>

                            <!-- Use a form for Order Now -->
                            <form action="order-now.php" method="POST">
                                <input type="hidden" name="food" value="<?php echo $food['title']; ?>">
                                <button type="submit" class="btn btn-primary"><i class="fas fa-shopping-cart"></i> Order Now</button>
                            </form>
                        </div>
                    </div>
                    <?php
                }
            } else {
                // If no food items are found
                echo "<p>No food items available.</p>";
            }
            ?>
            <div class="clearfix"></div>
        </div>
    </section>
    <!-- fOOD Menu Section Ends Here -->

    <!-- JavaScript for Responsive Navigation -->
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            var menuToggle = document.getElementById('menu-toggle');
            var mobileMenu = document.getElementById('mobile-menu');

            menuToggle.addEventListener('click', function () {
                mobileMenu.classList.toggle('show');
            });
        });
    </script>

<!-- Footer Starts Here -->
<?php include('partials/footer.php'); ?>
<!-- Footer Ends Here -->
