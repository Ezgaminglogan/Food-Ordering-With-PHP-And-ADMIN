<?php
// cancel-order.php

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['order_id'])) {
    $orderId = $_POST['order_id'];

    // Database connection using PDO
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "food-order";

    try {
        $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Update status to 'Cancelled' in tbl_order
        $sqlCancelOrder = "UPDATE tbl_order SET status = 'Cancelled' WHERE id = :order_id AND status = 'Ordered'";
        $stmtCancelOrder = $conn->prepare($sqlCancelOrder);
        $stmtCancelOrder->bindParam(':order_id', $orderId);
        $stmtCancelOrder->execute();

        echo "Order cancelled successfully";
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
    } finally {
        // Close the PDO connection
        $conn = null;
    }
} else {
    echo "Invalid request";
}
?>
