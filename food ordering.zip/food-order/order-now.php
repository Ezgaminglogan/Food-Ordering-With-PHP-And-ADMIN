<?php
include('partials/menu.php');

// Database connection using PDO
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "food-order";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}

// Get the selected food item from the form
$selectedFood = isset($_POST['food']) ? $_POST['food'] : null;

// Initialize $qty to a default value
$qty = 1;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit-order'])) {
    // Get form data
    $qty = isset($_POST['qty']) ? intval($_POST['qty']) : 1;
    $fullName = isset($_POST['full-name']) ? $_POST['full-name'] : '';
    $contactNumber = isset($_POST['contact-number']) ? $_POST['contact-number'] : '';
    $address = isset($_POST['address']) ? $_POST['address'] : '';
    $paymentMethod = isset($_POST['payment']) ? $_POST['payment'] : '';

    // Fetch the selected food item details from the database
    $sqlFood = "SELECT * FROM tbl_food WHERE title = :selectedFood";
    $stmtFood = $conn->prepare($sqlFood);
    $stmtFood->bindParam(':selectedFood', $selectedFood);
    $stmtFood->execute();
    $selectedFoodDetails = $stmtFood->fetch(PDO::FETCH_ASSOC);

    // Check if the available stocks are enough
    if ($selectedFoodDetails['stocks'] < $qty) {
        echo "<p style='color:white;'>Not enough stocks available. Please reduce the quantity.</p>";
    } else {
        // Calculate total price with 10% discount
        $discount = 0.10; // 10% discount
        $discountedPrice = $selectedFoodDetails['price'] - ($selectedFoodDetails['price'] * $discount);
        $totalPrice = $qty * $discountedPrice;

        // Subtract ordered quantity from stocks
        $remainingStocks = $selectedFoodDetails['stocks'] - $qty;

        // Update stocks and modified_at in tbl_food
        $sqlUpdateStocks = "UPDATE tbl_food SET stocks = :remainingStocks, modified_at = CURRENT_TIMESTAMP WHERE title = :selectedFood";
        $stmtUpdateStocks = $conn->prepare($sqlUpdateStocks);
        $stmtUpdateStocks->bindParam(':remainingStocks', $remainingStocks);
        $stmtUpdateStocks->bindParam(':selectedFood', $selectedFood);
        $stmtUpdateStocks->execute();

        // Insert order into tbl_order
        $sqlOrder = "INSERT INTO tbl_order (food, price, qty, total, phone_number, fullName, address, mode_of_payment, order_date, status) 
            VALUES (:food, :price, :qty, :total, :phone_number, :fullName, :address, :mode_of_payment, NOW(), 'Ordered')";
        $stmtOrder = $conn->prepare($sqlOrder);
        $stmtOrder->bindParam(':food', $selectedFoodDetails['title']);
        $stmtOrder->bindParam(':price', $discountedPrice);
        $stmtOrder->bindParam(':qty', $qty);
        $stmtOrder->bindParam(':total', $totalPrice);
        $stmtOrder->bindParam(':phone_number', $contactNumber);
        $stmtOrder->bindParam(':fullName', $fullName);
        $stmtOrder->bindParam(':address', $address);
        $stmtOrder->bindParam(':mode_of_payment', $paymentMethod);
        $stmtOrder->execute();

        // Display success message with JavaScript alert
        echo "<script>
            setTimeout(function() {
                alert('Order placed successfully with 10% discount! Redirecting...');
                window.location.href = 'order.php';
            }, 2000);
          </script>";
        exit();
    }
}
?>

<!-- Add your head content here -->
<style>
    /* Add your custom styles here */
    .food-search {
        padding: 20px;
    }

    .order {
        margin-top: 10px;
    }

    .order fieldset {
        margin-bottom: 20px;
    }

    .order img {
        display: flex;
        align-items: center;
        justify-content: center;
        max-width: 100%;
        /* Change to 100% to make the image responsive */
        height: auto;
        margin: 0 auto;
        /* Center the image horizontally */
    }

    .input-responsive {
        width: 100%;
        padding: 8px;
        margin: 8px 0;
        box-sizing: border-box;
    }

    .btn {
        margin-right: 10px;
    }

    @media (max-width: 768px) {
        .order img {
            width: 100%;
        }
    }

    .food-menu-img {
        text-align: center;
        /* Center the image */
        margin-left: 25%;
    }

    .food-menu-desc1 {
        text-align: center;
        /* Center the description */
    }
</style>

<!-- Order Section Starts Here -->
<section class="food-search">
    <div class="container">
        <h2 class="text-center text-white">Fill this form to confirm your order.</h2>

        <?php
                            // Check if the form is submitted and a valid food item is selected
                            if ($selectedFood) {
                                // Fetch the selected food item details from the database
                                $sql = "SELECT * FROM tbl_food WHERE title = :selectedFood";
                                $stmt = $conn->prepare($sql);
                                $stmt->bindParam(':selectedFood', $selectedFood);
                                $stmt->execute();
                                $selectedFoodDetails = $stmt->fetch(PDO::FETCH_ASSOC);

                                // Display the selected food item in the order form
                    echo "<form action='' method='POST' class='order'>";
                    echo "<fieldset>";
                    echo "<legend>Selected Food</legend>";

                    echo "<div class='food-menu-img'>";
                    echo "<img src='images/{$selectedFoodDetails['image_name']}' alt='{$selectedFood}' class='img-responsive img-curve'>";
                    echo "</div>";

                    echo "<div class='food-menu-desc1'>";
                    echo "<h3>{$selectedFoodDetails['title']}</h3>";
                    echo "<p class='food-price' >&#x20B1;{$selectedFoodDetails['price']}</p>";
                    echo "<p class='food-stocks'>Stocks: {$selectedFoodDetails['stocks']}</p>";

                    echo "<div class='order-label'>Quantity</div>";
                    echo "<input type='number' name='qty' class='input-responsive' value='{$qty}' max='{$selectedFoodDetails['stocks']}' required>";

                    echo "</div>";

                    echo "</fieldset>";

                    // Display the delivery details form
                    echo "<fieldset>";
                    echo "<legend>Delivery Details</legend>";

                    echo "<label for='full-name'>Full Name:</label>";
                    echo "<input type='text' id='full-name' name='full-name' class='input-responsive' required> <br>";

                    echo "<label for='contact-number'>Contact Number:</label>";
                    echo "<input type='text' id='contact-number' name='contact-number' class='input-responsive' pattern='\d{11}' title='Please enter a valid 11-digit contact number' required><br>";

                    echo "<label for='address'>Address:</label>";
                    echo "<input type='text' id='address' name='address' class='input-responsive' required> <br>";

                    // Add Dropdown Mode of Payment with icons
                    echo "<div class='order-label'>Mode of Payment</div>";
                    echo "<select name='payment' id='payment-method' class='input-responsive' required>";
                    echo "<option value='cash_on_delivery'>Cash on Delivery <i class='fas fa-money-bill-wave'></i></option>";
                    echo "<option value='gcash'>GCash <i class='fas fa-mobile-alt'></i></option>";
                    echo "</select><br>";

                    // Display the QR code for GCash payment
                    $gcashQRCodePath = 'qrCode/Gcash.png';  // Update the path to your GCash QR code image
                    echo "<div id='gcash-qrcode-container' style='display:none;'>";
                    echo "<img src='{$gcashQRCodePath}' alt='GCash QR Code' class='img-responsive' style='max-width: 300px; max-height: 300px; text-align:center'>";
                    echo "<p>Scan the QR Code to make a GCash payment.</p>";
                    echo "</div>";

                    echo "<input type='hidden' name='food' value='{$selectedFood}'><br>";

                    // Style the "Order Now" button based on stock availability
                    $orderNowBtnStyle = $selectedFoodDetails['stocks'] === 0 ? 'style="background-color: grey; cursor: not-allowed;" disabled' : '';
                    echo "<input type='submit' name='submit-order' value='Order Now' class='btn btn-primary' $orderNowBtnStyle>";

                    // Add Cancel button to move to foods-users.php
                    echo "<a href='foods.php' class='btn btn-secondary'>Cancel</a>";

                    echo "</fieldset>";

                    echo "</form>";
        } else {
            // If no food item is selected, display an error message
            echo "<p style='color:white;'>No food item selected for order.</p>";
        }

        // Close the PDO connection
        $conn = null;
        ?>
    </div>
</section>
<!-- Order Section Ends Here -->

<!-- JavaScript -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    var paymentMethodSelect = document.getElementById('payment-method');
    var gcashQRCodeContainer = document.getElementById('gcash-qrcode-container');
    paymentMethodSelect.addEventListener('change', function() {
        if (paymentMethodSelect.value === 'gcash') {
            gcashQRCodeContainer.style.display = 'block';
        } else {
            gcashQRCodeContainer.style.display = 'none';
        }
    });
});
</script>

<!-- Footer Starts Here -->
<?php include('partials/footer.php'); ?>
<!-- Footer Ends Here -->
